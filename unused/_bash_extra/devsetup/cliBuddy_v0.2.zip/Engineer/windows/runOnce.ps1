﻿# Validate AWS Cli Version

$AWSVersion=(aws --version).Split('/')[1].Split(' ')[0].Trim()

if ($AWSVersion -ge 2.10) {
    Write-Output "AWS Cli v2 alreay installed"

} elseif ($AWSVersion -le 2.10) {
    Write-Output "Please upgrade AWS Cli v2"
    Start-Sleep -Seconds 05
    Start-Process https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html#getting-started-install-instructions
    exit 1

} else {
    Write-Output "Please install AWS Cli v2"
    Start-Sleep -Seconds 05
    Start-Process https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html#getting-started-install-instructions
    exit 1

}

# Validate Kubectl

if($(kubectl version --client=true) | Select-String -SimpleMatch 'GitVersion:"v1.2') {
    Write-Output "Kubectl alreay installed"
} else {
    Write-Output "Please install kubectl"
    Start-Sleep -Seconds 05
    Start-Process https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/#install-kubectl-binary-with-curl-on-windows
    exit 1
}

# Copy configs

$today=Get-Date -format yyyy-MM-dd-hh-mm-ss

if (Test-Path $env:USERPROFILE\.aws) {
    Write-Output "Backing up exsing credentials and config"
    Rename-Item $env:USERPROFILE\.aws\config -NewName $env:USERPROFILE\.aws\config-$today-backup -ErrorAction SilentlyContinue;
    Rename-Item $env:USERPROFILE\.aws\credentials -NewName $env:USERPROFILE\.aws\credentials-$today-backup -ErrorAction SilentlyContinue;

    Write-Output "copying AWSconfig to $env:USERPROFILE\.aws"
    Copy-Item ..\AWSconfig -Destination $env:USERPROFILE\.aws\config
    Copy-Item ..\AWScredentials -Destination $env:USERPROFILE\.aws\credentials

} else {
    Write-Output ".aws folder doesn't exists, creating it"
    New-Item -Path $env:USERPROFILE -Name .aws -ItemType Directory

    Write-Output "copying AWSconfig to $env:USERPROFILE\.aws"
    Copy-Item ..\AWSconfig -Destination $env:USERPROFILE\.aws\config
    Copy-Item ..\AWScredentials -Destination $env:USERPROFILE\.aws\credentials
}

if (Test-Path $env:USERPROFILE\.kube) {
    Write-Output "Backing up exsing config"
    Rename-Item $env:USERPROFILE\.kube\config -NewName $env:USERPROFILE\.kube\config-$today-backup -ErrorAction SilentlyContinue;

    Write-Output "copying Kubeconfig to $env:USERPROFILE\.kube"
    Copy-Item ..\KUBEconfig -Destination $env:USERPROFILE\.kube\config

} else {
    Write-Output ".kube folder doesn't exists, creating it"
    New-Item -Path $env:USERPROFILE -Name .kube -ItemType Directory

    Write-Output "copying Kubeconfig to $env:USERPROFILE\.kube"
    Copy-Item ..\KUBEconfig -Destination $env:USERPROFILE\.kube\config
}

Start-Sleep -Seconds 05
