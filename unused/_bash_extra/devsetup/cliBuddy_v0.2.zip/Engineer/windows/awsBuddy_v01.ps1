﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Select an AWS environment'
$form.Size = New-Object System.Drawing.Size(300,200)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(75,120)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'OK'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(150,120)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Cancel'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please select the AWS environment:'
$form.Controls.Add($label)

$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Location = New-Object System.Drawing.Point(10,40)
$listBox.Size = New-Object System.Drawing.Size(260,20)
$listBox.Height = 80

[void] $listBox.Items.Add('aaedev-mumbai')
[void] $listBox.Items.Add('aaedev-oregon')
[void] $listBox.Items.Add('esp')
[void] $listBox.Items.Add('test-global')
[void] $listBox.Items.Add('performance')
[void] $listBox.Items.Add('ba-headless')


$form.Controls.Add($listBox)

$form.Topmost = $true

$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $x = $listBox.SelectedItem
    switch ($x)
    {
        aaedev-mumbai {$awsACC=679329828108; $awsRegion="ap-south-1"}
        aaedev-oregon {$awsACC=679329828108; $awsRegion="us-west-2"}
        esp {$awsACC=463221208343; $awsRegion="us-east-1"}
        test-global {$awsACC=508714954883; $awsRegion="us-east-1"}
        performance {$awsACC=700352514885; $awsRegion="us-west-2"}
        ba-headless {$awsACC=727376579312; $awsRegion="us-west-2"}
    }
    $session_name = (whoami).Split('\')[1]
    aws sso login --profile aaieng
    Write-Output "Retrieve credential of $x"
    $token = (aws sts assume-role --profile aaieng --role-arn arn:aws:iam::${awsACC}:role/global-engineer-role --role-session-name $session_name)
    $AccessKeyId = "'"+(($token | ConvertFrom-Json).Credentials.AccessKeyId).trim()+"'"
    $SecretAccessKey = "'"+($token | ConvertFrom-Json).Credentials.SecretAccessKey.trim()+"'"
    $SessionToken = "'"+($token | ConvertFrom-Json).Credentials.SessionToken.trim()+"'"
    $awsRegion = "'" + $awsRegion + "'"
    PowerShell -NoExit "[System.Environment]::SetEnvironmentVariable('AWS_ACCESS_KEY_ID',$AccessKeyId); [System.Environment]::SetEnvironmentVariable('AWS_SECRET_ACCESS_KEY',${SecretAccessKey}); [System.Environment]::SetEnvironmentVariable('AWS_SESSION_TOKEN',${SessionToken}); [System.Environment]::SetEnvironmentVariable('AWS_DEFAULT_REGION',${awsRegion})"
}