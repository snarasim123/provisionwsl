#!/bin/bash

# environment options
echo "Please select the environment you want to connect :"
echo "  1)aaedev-mumbai  1"
echo "  2)aaedev-oregon  2"
echo "  3)esp-cluster    3"
echo "  4)test-global    4" 
echo "  5)performance    5"
echo "  6)ba-headless    6"


read -r n
case $n in
  1)
	echo "Switching to aaedev-mumbai";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context aaedev-mumbai; exec bash;"
	;;
  2) 
	echo "Switching to aaedev-oregon";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context aaedev-oregon; exec bash;"
	;;
  3) 
	echo "Switching to esp-cluster";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context esp-cluster; exec bash;"
	;;
  4) 
	echo "Switching to test-global";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context test-global; exec bash;"
	;;
  5) 	echo "Switching to performance";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context performance; exec bash;"
	;;
  6) 	echo "Switching to ba-headless";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --no-browser --profile aaieng; kubectl config use-context ba-headless; exec bash;"
	;;
  *) 	echo "invalid option"
	;;
esac

