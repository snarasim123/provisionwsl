#!/bin/bash

# environment options
echo "Please select the AWS environment you want to connect:"
echo "  1)aaedev-mumbai  1"
echo "  2)aaedev-oregon  2"
echo "  3)esp            3"
echo "  4)test-global    4" 
echo "  5)performance    5"
echo "  6)ba-headless    6"

retrieveToken() {
	awsENV=$1
	awsACC=$2
	awsRegion=$3
	session_name=`cat ~/.clibuddy/config`

	echo "Retrieve credential of $awsENV"
	aws sso login --no-browser --profile aaieng
	token=`aws sts assume-role --profile aaieng --role-arn arn:aws:iam::"${awsACC}":role/global-engineer-role --role-session-name "${session_name}"`
	accessKeyId=`echo "$token" | jq -r .Credentials.AccessKeyId`
	secretAccessKey=`echo "$token" | jq -r .Credentials.SecretAccessKey`
	sessionToken=`echo "$token" | jq -r .Credentials.SessionToken`

	bash -c "export AWS_ACCESS_KEY_ID=${accessKeyId}; export AWS_SECRET_ACCESS_KEY=${secretAccessKey}; export AWS_SESSION_TOKEN=${sessionToken}; export AWS_DEFAULT_REGION=${awsRegion}; exec bash;"

}


read -r n
case $n in
  1)
	retrieveToken "aaedev-mumbai" "679329828108" "ap-south-1"
	;;
  2) 
	retrieveToken "aaedev-oregon" "679329828108" "us-west-2"
	;;
  3) 
	retrieveToken "esp" "463221208343" "us-east-1"
	;;
  4) 
	retrieveToken "test-global" "508714954883" "us-east-1"
	;;
  5)
	retrieveToken "performance" "700352514885" "us-west-2"
	;;
  6)
	retrieveToken "ba-headless" "727376579312" "us-west-2"
	;;
  *) 	echo "invalid option"
	;;
esac
