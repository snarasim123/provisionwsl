#!/bin/bash

function pause(){
 read -r -s -n 1 -p "Press any key to continue . . ."
 echo ""
}

# Read the user input   
echo "Enter the user name: "  
read -r user_name  
echo "The Current User Name is $user_name"  


# Validate AWS Cli Version
if `aws --version | grep -q "aws-cli/2.10"`; then 
	echo "AWS Cli v2 alreay installed"
elif `aws --version | grep -q "aws-cli/2."`; then 
	echo "Please upgrade AWS Cli v2"
	echo "refer to this link: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html#getting-started-install-instructions"
	pause
else
	echo "Please install AWS Cli v2"
	echo "refer to this link: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html#getting-started-install-instructions"
	pause
fi

# Validate Kubectl
if `kubectl version --client=true | grep -q 'Major:"1", Minor:"2'`; then
	echo "Kubectl alreay installed"
else
	echo "Please install kubectl"
	echo "refer to this link: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/#install-kubectl-binary-with-curl-on-linux"
	pause
fi

# Validate jq
if `jq --version | grep -q "jq-1."`; then
	echo "jq alreay installed"
else
	echo "Please install jq"
	echo "refer to this link: https://stedolan.github.io/jq/download/"
	pause
fi

# Copy configs
today=`date "+%Y%m%d%H%M%S"`

if [ -d "$HOME/.aws" ]; then
	echo "Backing up exsing credentials and config"
	mv ~/.aws/config ~/.aws/config-$today-backup
	mv ~/.aws/credentials ~/.aws/credentials-$today-backup

	echo "copying AWSconfig to ~/.aws"
	cp ../AWSconfig ~/.aws/config
	cp ../AWScredentials ~/.aws/credentials
else
	echo ".aws folder doesn't exists, creating it"
	mkdir ~/.aws
	echo "copying AWSconfig to ~/.aws"
	cp ../AWSconfig ~/.aws/config
	cp ../AWScredentials ~/.aws/credentials
fi

if [ -d "$HOME/.kube" ]; then
        echo "Backing up exsing config"
        mv ~/.kube/config ~/.kube/config-$today-backup

        echo "copying Kubeconfig to ~/.kube"
        cp ../KUBEconfig ~/.kube/config
else
        echo ".kube folder doesn't exists, creating it"
        mkdir ~/.kube

        echo "copying Kubeconfig to ~/.kube"
        cp ../KUBEconfig ~/.kube/config
fi

if [ -d "$HOME/.clibuddy" ]; then
        echo "$user_name" > ~/.clibuddy/config
else
        echo ".clibuddy folder doesn't exists, creating it"
        mkdir ~/.clibuddy

        echo "$user_name" > ~/.clibuddy/config
fi

pause
