#!/bin/bash

# environment options
echo "Please select the AWS environment you want to connect:"
echo "  1)performance    1"

retrieveToken() {
	awsENV=$1
	awsACC=$2
	awsRegion=$3
	session_name=`cat ~/.clibuddy/config`

	echo "Retrieve credential of $awsENV"
	aws sso login --profile aaieng
	token=`aws sts assume-role --profile aaieng --role-arn arn:aws:iam::"${awsACC}":role/global-power-users-role --role-session-name "${session_name}"`
	accessKeyId=`echo "$token" | jq -r .Credentials.AccessKeyId`
	secretAccessKey=`echo "$token" | jq -r .Credentials.SecretAccessKey`
	sessionToken=`echo "$token" | jq -r .Credentials.SessionToken`

	bash -c "export AWS_ACCESS_KEY_ID=${accessKeyId}; export AWS_SECRET_ACCESS_KEY=${secretAccessKey}; export AWS_SESSION_TOKEN=${sessionToken}; export AWS_DEFAULT_REGION=${awsRegion}; exec bash;"

}


read -r n
case $n in
  1)
	retrieveToken "performance" "700352514885" "us-west-2"
	;;
  *) 	echo "invalid option"
	;;
esac
