#!/bin/bash

# environment options
echo "Please select the environment you want to connect :"
echo "  1)performance    1"


read -r n
case $n in
  1) 	echo "Switching to performance";
	bash -c "export AWS_PROFILE=aaieng; aws sso login --profile aaieng; kubectl config use-context performance; exec bash;"
	;;
  *) 	echo "invalid option"
	;;
esac
